# Decision-Tree-Using-ID3-
Problem : Write a program to demonstrate the working of the decision tree based ID3 algorithm. Use an appropriate data set for building the decision tree and  apply this knowledge to classify a new sample.
